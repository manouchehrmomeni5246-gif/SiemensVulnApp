package com.manouchehr.siemensvulnapp

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.content.*
import android.net.Uri
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    private val allItems = mutableListOf<Vuln>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(makeUi())
        loadSample()
        fetchSiemensFeed()
    }

    private fun makeUi(): View {
        val root = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 38, 28, 28)
            background = gradient(0xFF071A2FL.toInt(), 0xFF103B63L.toInt())
        }
        root.addView(container)

        val title = TextView(this).apply {
            text = "Siemens Vulnerability Center"
            textSize = 25f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        container.addView(title)

        val subtitle = TextView(this).apply {
            text = "CVE • CVSS • Siemens CERT • OT Security"
            textSize = 14f
            setTextColor(0xFFD8E9FF.toInt())
            setPadding(0, 8, 0, 18)
        }
        container.addView(subtitle)

        search = EditText(this).apply {
            hint = "Search: S7, PLC, HMI, WinCC, TIA, SCALANCE"
            textSize = 15f
            singleLine = true
            setPadding(26, 12, 26, 12)
            setTextColor(Color.WHITE)
            setHintTextColor(0xFFB7CDE6.toInt())
            background = rounded(0xFF123F68.toInt(), 26f, 0xFF2F80C9.toInt())
        }
        container.addView(search, LinearLayout.LayoutParams(-1, 62))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 16, 0, 8) }
        val btnSearch = button("Search") { filter() }
        val btnAbout = button("About") { showAbout() }
        row.addView(btnSearch, LinearLayout.LayoutParams(0, 56, 1f))
        row.addView(space(12), LinearLayout.LayoutParams(12, 1))
        row.addView(btnAbout, LinearLayout.LayoutParams(0, 56, 1f))
        container.addView(row)

        status = TextView(this).apply {
            text = "Loading Siemens feed..."
            textSize = 13f
            setTextColor(0xFFBFE0FF.toInt())
            setPadding(0, 8, 0, 8)
        }
        container.addView(status)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        container.addView(list)
        return root
    }

    private fun button(text: String, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        background = rounded(0xFF1976D2.toInt(), 26f, 0xFF59B7FF.toInt())
        setOnClickListener { action() }
    }

    private fun loadSample() {
        allItems.add(Vuln("CVE Search", "Live Siemens advisories", "Search PLC, HMI, WinCC, TIA Portal, SCALANCE and SIMATIC products.", "N/A", "Info", "https://www.siemens.com/global/en/products/services/cert.html"))
        render(allItems)
    }

    private fun fetchSiemensFeed() {
        thread {
            try {
                val txt = URL("https://cert-portal.siemens.com/productcert/csaf/ssa-feed-tlp-white.json").readText()
                val obj = JSONObject(txt)
                val entries = obj.getJSONObject("feed").getJSONArray("entry")
                allItems.clear()
                for (i in 0 until minOf(entries.length(), 40)) {
                    val e = entries.getJSONObject(i)
                    val title = e.optString("title", "Siemens Advisory")
                    val summary = e.optJSONObject("summary")?.optString("content") ?: "No summary"
                    val link = e.optJSONObject("content")?.optString("src") ?: ""
                    val sev = detectSeverity(summary + title)
                    allItems.add(Vuln("SSA", title, summary, "See advisory", sev, link))
                }
                runOnUiThread { status.text = "Loaded ${allItems.size} Siemens advisories"; filter() }
            } catch (ex: Exception) {
                runOnUiThread { status.text = "Offline/sample mode. Check internet or GitHub build." }
            }
        }
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        val res = if (q.isBlank()) allItems else allItems.filter {
            it.title.lowercase().contains(q) || it.desc.lowercase().contains(q) || it.cve.lowercase().contains(q)
        }
        render(res)
    }

    private fun render(items: List<Vuln>) {
        list.removeAllViews()
        items.forEach { list.addView(card(it)) }
    }

    private fun card(v: Vuln): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 20)
            background = rounded(0xFFFFFFFF.toInt(), 24f, 0xFFE0F1FF.toInt())
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 12, 0, 12) }
        c.layoutParams = lp
        c.addView(text(v.cve, 13f, 0xFF1976D2.toInt(), true))
        c.addView(text(v.title, 18f, 0xFF071A2F.toInt(), true))
        c.addView(text("CVSS: ${v.cvss}   Severity: ${v.severity}", 14f, severityColor(v.severity), true))
        c.addView(text(v.desc.take(420), 14f, 0xFF334155.toInt(), false))
        if (v.url.isNotBlank()) {
            val link = text("Open source advisory", 14f, 0xFF0B63CE.toInt(), true)
            link.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(v.url))) }
            c.addView(link)
        }
        return c
    }

    private fun showAbout() {
        android.app.AlertDialog.Builder(this)
            .setTitle("About")
            .setMessage("Siemens Vulnerability Center\n\nCreated for:\nManouchehr Momeni\n\nSources: Siemens ProductCERT CSAF, CVE/CVSS references and OT security advisories.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        setPadding(0, 4, 0, 4)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radius: Float, stroke: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(2, stroke)
    }
    private fun gradient(a: Int, b: Int) = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(a, b))
    private fun space(w: Int) = Space(this)
    private fun detectSeverity(s: String) = when {
        s.contains("critical", true) -> "Critical"
        s.contains("high", true) -> "High"
        s.contains("medium", true) -> "Medium"
        else -> "Unknown"
    }
    private fun severityColor(s: String) = when (s) {
        "Critical" -> 0xFFB91C1C.toInt()
        "High" -> 0xFFEA580C.toInt()
        "Medium" -> 0xFFCA8A04.toInt()
        else -> 0xFF2563EB.toInt()
    }
}

data class Vuln(val cve: String, val title: String, val desc: String, val cvss: String, val severity: String, val url: String)
